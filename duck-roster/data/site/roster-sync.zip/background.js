// Background: Google sign-in (OAuth implicit flow via identity.launchWebAuthFlow) and the Google Calendar sync.
if (typeof importScripts === 'function') importScripts('shared.js');
(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const S = RosterShared, CFG = S.CONFIG;
  const SCOPE = 'https://www.googleapis.com/auth/calendar.app.created';
  const API = 'https://www.googleapis.com/calendar/v3/';
  class NeedsAuth extends Error {}

  // The hour-long access token is kept in storage.session: memory only, and out of reach of the page scripts.
  async function getToken(interactive) {
    const { auth } = await api.storage.session.get('auth');
    if (auth && auth.expiry - 60000 > Date.now()) return auth.token;
    if (!interactive && (await api.storage.local.get('signedOut')).signedOut) throw new NeedsAuth('disconnected');
    const state = crypto.randomUUID();
    const p = new URLSearchParams({ client_id: CFG.clientId, redirect_uri: api.identity.getRedirectURL(), response_type: 'token', scope: SCOPE, include_granted_scopes: 'true', state });
    if (!interactive) p.set('prompt', 'none');
    let result;
    try { result = await api.identity.launchWebAuthFlow({ url: 'https://accounts.google.com/o/oauth2/v2/auth?' + p, interactive }); }
    catch (e) { throw new NeedsAuth(e && e.message || String(e)); }
    const frag = new URLSearchParams(String(result).split('#')[1] || '');
    const token = frag.get('access_token');
    if (!token || frag.get('state') !== state) throw new NeedsAuth(frag.get('error') || 'no token returned');
    await api.storage.session.set({ auth: { token, expiry: Date.now() + (+frag.get('expires_in') || 3600) * 1000 } });
    if (interactive) await api.storage.local.remove('signedOut');
    return token;
  }

  async function gapi(method, path, body, interactive, retry = true) {
    const token = await getToken(interactive);
    const res = await fetch(API + path, { method, headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    if (res.status === 401 && retry) { await api.storage.session.remove('auth'); return gapi(method, path, body, interactive, false); }
    if (res.status === 204) return null;
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { const err = new Error((data.error && data.error.message) || ('HTTP ' + res.status)); err.status = res.status; throw err; }
    return data;
  }

  // The calendar the shifts live in: remembered by id, otherwise found by name (after a reinstall), otherwise created.
  async function calendarId(interactive) {
    const { calendarId } = await api.storage.local.get('calendarId');
    if (calendarId) return calendarId;
    let found = null;
    try {
      const list = await gapi('GET', 'users/me/calendarList?minAccessRole=owner&maxResults=250', null, interactive);
      found = (list.items || []).find(c => c.summary === CFG.calendarName);
    } catch (e) { if (e.status !== 403) throw e; }
    const id = found ? found.id : (await gapi('POST', 'calendars', { summary: CFG.calendarName, timeZone: CFG.timeZone }, interactive)).id;
    await api.storage.local.set({ calendarId: id });
    return id;
  }

  function toGoogle(ev, id) {
    const body = { id, summary: ev.summary, status: 'confirmed', description: 'Synced from Employee Online by Roster Sync (' + ev.source + ')', extendedProperties: { private: { rosterSync: '1', sig: S.signature(ev) } } };
    if (ev.location) body.location = ev.location;
    if (ev.allDay) { body.start = { date: ev.start }; body.end = { date: ev.end }; }
    else { body.start = { dateTime: ev.start, timeZone: CFG.timeZone }; body.end = { dateTime: ev.end, timeZone: CFG.timeZone }; }
    return body;
  }

  // Make the calendar match the roster for the weeks on screen: add new shifts, update changed ones,
  // remove shifts we created that are no longer on the roster. Never touches events we did not create.
  async function syncRoster(roster, interactive, retry = true) {
    const calId = await calendarId(interactive);
    const base = 'calendars/' + encodeURIComponent(calId) + '/events';
    const q = new URLSearchParams({ privateExtendedProperty: 'rosterSync=1', timeMin: S.addDaysStr(roster.rangeStart, -1) + 'T00:00:00Z', timeMax: S.addDaysStr(roster.rangeEnd, 1) + 'T00:00:00Z', maxResults: '2500', singleEvents: 'true', timeZone: CFG.timeZone });
    let list;
    try { list = await gapi('GET', base + '?' + q, null, interactive); }
    catch (e) {
      if (e.status !== 404 || !retry) throw e; // the calendar was deleted in Google Calendar, so make a new one
      await api.storage.local.remove('calendarId');
      return syncRoster(roster, interactive, false);
    }
    const existing = new Map((list.items || []).map(e => [e.id, e]));
    const wanted = new Set();
    let created = 0, updated = 0, deleted = 0;
    for (const ev of roster.events) {
      const id = S.eventId(ev.uid);
      wanted.add(id);
      const body = toGoogle(ev, id);
      const cur = existing.get(id);
      if (cur?.extendedProperties?.private?.sig === body.extendedProperties.private.sig) continue;
      if (cur) { await gapi('PUT', base + '/' + id, body, interactive); updated++; continue; }
      try { await gapi('POST', base, body, interactive); created++; }
      catch (e) {
        if (e.status !== 409) throw e; // 409: a deleted copy still owns this id, so revive it
        await gapi('PUT', base + '/' + id, body, interactive); updated++;
      }
    }
    for (const [id, e] of existing) {
      if (wanted.has(id)) continue;
      const day = (e.start && (e.start.date || String(e.start.dateTime || '').slice(0, 10))) || '';
      if (day >= roster.rangeStart && day < roster.rangeEnd) { await gapi('DELETE', base + '/' + id, null, interactive); deleted++; }
    }
    return { ok: true, created, updated, deleted };
  }

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        switch (msg.type) {
          case 'sync': {
            const r = await syncRoster(msg.roster, !!msg.interactive);
            await api.storage.local.set({ lastSync: { at: Date.now(), shifts: msg.roster.events.length, created: r.created, updated: r.updated, deleted: r.deleted } });
            return r;
          }
          case 'status': {
            const { lastSync } = await api.storage.local.get('lastSync');
            return { lastSync, signedIn: await getToken(false).then(() => true, () => false) };
          }
          case 'signOut': {
            // Revoking a live token removes Google's grant; the flag stops a silent reconnect if revoking fails.
            const token = await getToken(false).catch(() => null);
            if (token) await fetch('https://oauth2.googleapis.com/revoke?token=' + encodeURIComponent(token), { method: 'POST' }).catch(() => {});
            await api.storage.local.set({ signedOut: true });
            await api.storage.session.remove('auth');
            return { ok: true };
          }
        }
        return { error: 'unknown message ' + msg.type };
      } catch (e) {
        if (e instanceof NeedsAuth) return { needsAuth: true, detail: e.message };
        return { error: e && e.message || String(e) };
      }
    })().then(sendResponse);
    return true;
  });
})();
