// Background: Google sign-in (OAuth implicit flow via identity.launchWebAuthFlow) and the Google Calendar sync.
if (typeof importScripts === 'function') importScripts('shared.js');
(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const S = RosterShared, CFG = S.CONFIG;
  const SCOPE = 'https://www.googleapis.com/auth/calendar.app.created';
  const API = 'https://www.googleapis.com/calendar/v3/';
  // Each Employee Online site (one per health district) owns only the events it made. Before 1.2.0 the extension
  // ran on patheol alone, so events without a site tag are patheol's, and patheol keeps the old untagged ids.
  const FIRST_SITE = 'patheol.ros.health.nsw.gov.au';
  class NeedsAuth extends Error {}

  // The hour-long access token is kept in storage.session: memory only, and out of reach of the page scripts.
  async function getToken(interactive) {
    const { auth } = await api.storage.session.get('auth');
    if (auth && auth.expiry - 60000 > Date.now()) return auth.token;
    if (!interactive && (await api.storage.local.get('signedOut')).signedOut) throw new NeedsAuth('disconnected');
    const state = crypto.randomUUID();
    const p = new URLSearchParams({ client_id: CFG.clientId, redirect_uri: api.identity.getRedirectURL(), response_type: 'token', scope: SCOPE, include_granted_scopes: 'true', state });
    if (!interactive) p.set('prompt', 'none');
    let result;
    try { result = await api.identity.launchWebAuthFlow({ url: 'https://accounts.google.com/o/oauth2/v2/auth?' + p, interactive }); }
    catch (e) { throw new NeedsAuth(e && e.message || String(e)); }
    const frag = new URLSearchParams(String(result).split('#')[1] || '');
    const token = frag.get('access_token');
    if (!token || frag.get('state') !== state) throw new NeedsAuth(frag.get('error') || 'no token returned');
    await api.storage.session.set({ auth: { token, expiry: Date.now() + (+frag.get('expires_in') || 3600) * 1000 } });
    if (interactive) await api.storage.local.remove('signedOut');
    return token;
  }

  async function gapi(method, path, body, interactive, retry = true) {
    const token = await getToken(interactive);
    const res = await fetch(API + path, { method, headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    if (res.status === 401 && retry) { await api.storage.session.remove('auth'); return gapi(method, path, body, interactive, false); }
    if (res.status === 204) return null;
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { const err = new Error((data.error && data.error.message) || ('HTTP ' + res.status)); err.status = res.status; throw err; }
    return data;
  }

  // The calendar the shifts live in: remembered by id, otherwise found by name (after a reinstall), otherwise created.
  async function calendarId(interactive) {
    const { calendarId } = await api.storage.local.get('calendarId');
    if (calendarId) return calendarId;
    let found = null;
    try {
      const list = await gapi('GET', 'users/me/calendarList?minAccessRole=owner&maxResults=250', null, interactive);
      found = (list.items || []).find(c => c.summary === CFG.calendarName);
    } catch (e) { if (e.status !== 403) throw e; }
    const id = found ? found.id : (await gapi('POST', 'calendars', { summary: CFG.calendarName, timeZone: CFG.timeZone }, interactive)).id;
    await api.storage.local.set({ calendarId: id });
    return id;
  }

  // orig is the signature of the shift as first synced. A shift that differs from it is flagged: "Changed:" in the
  // title (shows in every calendar app), red in Google Calendar instead of its shift colour, and the notes say what it was.
  function toGoogle(ev, id, site, orig) {
    const sig = S.signature(ev), changed = orig !== sig;
    const note = changed ? 'Changed on ' + new Date().toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric', timeZone: CFG.timeZone }) + '. Originally: ' + S.describe(orig) + '.\n\n' : '';
    const body = { id, summary: (changed ? 'Changed: ' : '') + ev.summary, status: 'confirmed', description: note + 'Synced from Employee Online by Roster Sync (' + ev.source + ')', extendedProperties: { private: { rosterSync: '1', sig, site, orig } } };
    const colorId = changed ? '11' : ev.color; // 11 is Tomato
    if (colorId) body.colorId = colorId;
    if (ev.location) body.location = ev.location;
    if (ev.allDay) { body.start = { date: ev.start }; body.end = { date: ev.end }; }
    else { body.start = { dateTime: ev.start, timeZone: CFG.timeZone }; body.end = { dateTime: ev.end, timeZone: CFG.timeZone }; }
    return body;
  }

  // Make the calendar match the roster for the weeks on screen: add new shifts, update changed ones,
  // remove shifts this site created that are no longer on its roster. Never touches events made elsewhere.
  // A new start time or code gives a shift a new id, so a new shift on the same day as a removed one replaces it:
  // it carries over that event's original and is counted (and flagged) as changed.
  async function syncRoster(roster, interactive, retry = true) {
    const site = roster.site || FIRST_SITE;
    const mine = e => (e.extendedProperties?.private?.site || FIRST_SITE) === site;
    const calId = await calendarId(interactive);
    const base = 'calendars/' + encodeURIComponent(calId) + '/events';
    const q = new URLSearchParams({ privateExtendedProperty: 'rosterSync=1', timeMin: S.addDaysStr(roster.rangeStart, -1) + 'T00:00:00Z', timeMax: S.addDaysStr(roster.rangeEnd, 1) + 'T00:00:00Z', maxResults: '2500', singleEvents: 'true', orderBy: 'startTime', timeZone: CFG.timeZone });
    let list;
    try { list = await gapi('GET', base + '?' + q, null, interactive); }
    catch (e) {
      if (e.status !== 404 || !retry) throw e; // the calendar was deleted in Google Calendar, so make a new one
      await api.storage.local.remove('calendarId');
      return syncRoster(roster, interactive, false);
    }
    const existing = new Map((list.items || []).filter(mine).map(e => [e.id, e]));
    const idOf = ev => S.eventId(site === FIRST_SITE ? ev.uid : site + '/' + ev.uid);
    const dayOf = e => (e.start && (e.start.date || String(e.start.dateTime || '').slice(0, 10))) || '';
    const wanted = new Set(roster.events.map(idOf));
    const gone = [...existing.values()].filter(e => !wanted.has(e.id) && dayOf(e) >= roster.rangeStart && dayOf(e) < roster.rangeEnd);
    // Pair each new shift with a removed one on its day: first the event it originally was (a change back), then the
    // same kind of shift (a day shift that moved, even to another ward), then any.
    const priv = e => e.extendedProperties?.private || {};
    const kind = summary => String(summary).split(' · ')[0];
    const passes = [(e, ev) => (priv(e).orig || priv(e).sig) === S.signature(ev), (e, ev) => kind(String(priv(e).sig).split('|')[0]) === kind(ev.summary), () => true];
    const pair = new Map(), taken = new Set(); // new shift -> the removed event it replaces
    for (const match of passes) for (const ev of roster.events) {
      if (existing.has(idOf(ev)) || pair.has(ev)) continue;
      const g = gone.find(e => !taken.has(e) && dayOf(e) === ev.start.slice(0, 10) && match(e, ev));
      if (g) { pair.set(ev, g); taken.add(g); }
    }
    let created = 0, updated = 0;
    for (const ev of roster.events) {
      const id = idOf(ev), cur = existing.get(id), prev = cur || pair.get(ev);
      const p = prev && priv(prev);
      const body = toGoogle(ev, id, site, p ? p.orig || p.sig : S.signature(ev));
      if (cur) {
        // Same shift: update it if it changed, or just recolour it (events from before 1.3.0 have no colour).
        const same = p.sig === body.extendedProperties.private.sig;
        if (same && cur.colorId === body.colorId) continue;
        await gapi('PUT', base + '/' + id, body, interactive); if (!same) updated++; continue;
      }
      try { await gapi('POST', base, body, interactive); prev ? updated++ : created++; }
      catch (e) {
        if (e.status !== 409) throw e; // 409: a deleted copy still owns this id, so revive it
        await gapi('PUT', base + '/' + id, body, interactive); updated++;
      }
    }
    for (const e of gone) await gapi('DELETE', base + '/' + e.id, null, interactive);
    return { ok: true, created, updated, deleted: gone.length - taken.size };
  }

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      try {
        switch (msg.type) {
          case 'sync': {
            const r = await syncRoster(msg.roster, !!msg.interactive);
            await api.storage.local.set({ lastSync: { at: Date.now(), shifts: msg.roster.events.length, created: r.created, updated: r.updated, deleted: r.deleted } });
            return r;
          }
          case 'status': {
            const { lastSync } = await api.storage.local.get('lastSync');
            return { lastSync, signedIn: await getToken(false).then(() => true, () => false) };
          }
          case 'signOut': {
            // Revoking a live token removes Google's grant; the flag stops a silent reconnect if revoking fails.
            const token = await getToken(false).catch(() => null);
            if (token) await fetch('https://oauth2.googleapis.com/revoke?token=' + encodeURIComponent(token), { method: 'POST' }).catch(() => {});
            await api.storage.local.set({ signedOut: true });
            await api.storage.session.remove('auth');
            return { ok: true };
          }
        }
        return { error: 'unknown message ' + msg.type };
      } catch (e) {
        if (e instanceof NeedsAuth) return { needsAuth: true, detail: e.message };
        return { error: e && e.message || String(e) };
      }
    })().then(sendResponse);
    return true;
  });
})();
