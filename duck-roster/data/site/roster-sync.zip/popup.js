(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const S = RosterShared;
  const ORIGINS = api.runtime.getManifest().host_permissions;
  const $ = id => document.getElementById(id);
  const say = t => { $('msg').textContent = t; };

  async function refresh() {
    const allowed = await api.permissions.contains({ origins: ORIGINS });
    const st = await api.runtime.sendMessage({ type: 'status' });
    $('perm').hidden = allowed;
    $('signout').hidden = !st.signedIn;
    $('status').textContent = !allowed ? 'Roster Sync needs access to Employee Online.'
      : st.signedIn ? 'Connected to Google Calendar (calendar: ' + S.CONFIG.calendarName + ').'
      : 'Not connected. Open your roster and click Connect Google Calendar on the panel at the bottom right.';
    const l = st.lastSync;
    $('last').textContent = l ? 'Last sync ' + new Date(l.at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) + ': ' + S.shifts(l.shifts) + ' (' + l.created + ' new, ' + l.updated + ' changed, ' + l.deleted + ' removed).' : 'No sync yet.';
    const { autoSync = true } = await api.storage.sync.get('autoSync');
    $('auto').checked = autoSync;
  }

  $('signout').addEventListener('click', async () => {
    await api.runtime.sendMessage({ type: 'signOut' });
    say('Disconnected. Your Work roster calendar stays in Google Calendar.');
    refresh();
  });
  $('ics').addEventListener('click', async () => {
    try {
      const [tab] = await api.tabs.query({ active: true, currentWindow: true });
      const roster = tab && await api.tabs.sendMessage(tab.id, { type: 'getRoster' }).catch(() => null);
      if (!roster) throw new Error('Open your roster in Employee Online first, then try again.');
      if (!roster.events.length) throw new Error('No shifts found on the open page.');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([S.icsFromEvents(roster.events)], { type: 'text/calendar' }));
      a.download = 'roster-' + roster.monthKey + '.ics';
      document.body.appendChild(a); a.click(); a.remove();
      say('Saved ' + S.shifts(roster.events.length) + ' to ' + a.download + '. Open it to add them to Outlook or Apple Calendar.');
    } catch (e) { say(e.message); }
  });
  $('perm').addEventListener('click', async () => {
    if (await api.permissions.request({ origins: ORIGINS })) say('Allowed. Reload your roster page.');
    refresh();
  });
  $('auto').addEventListener('change', e => api.storage.sync.set({ autoSync: e.target.checked }));

  refresh().catch(e => say('Error: ' + e.message));
})();
