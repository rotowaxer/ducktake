// Runs on the Employee Online roster page: reads the shifts on screen, shows the Sync panel, syncs automatically.
(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const S = RosterShared;
  const MONTHS = { Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5, Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11 };
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  let ui = null, busy = false, timer = null, lastHash = null;

  // The month grid: a date box ("13 Oct 2026"), week rows whose first cell is a day number, and .fc-event
  // elements placed over the grid, so each one is mapped to a cell by its position.
  function readRoster() {
    // Find the month grid first, so text boxes on other pages (such as the sign-in form) are never read.
    const cal = Array.from(document.querySelectorAll('table')).find(t => /\bMon\b/.test(t.innerText) && /\bSun\b/.test(t.innerText));
    if (!cal) return null;
    const box = Array.from(document.querySelectorAll('input[type=text]'), i => i.value.match(/(\d{1,2}) (\w{3}) (\d{4})/)).find(Boolean);
    if (!box || MONTHS[box[2]] === undefined) return null;
    const month = MONTHS[box[2]], year = +box[3];
    const rows = Array.from(cal.querySelectorAll('tr')).filter(r => /^\d{1,2}$/.test(((r.children[0] || {}).innerText || '').trim()));
    if (!rows.length) return null;
    const weekday = DAYS.indexOf(((cal.rows[0] && cal.rows[0].cells[0] || {}).innerText || '').trim().slice(0, 3));
    const start = S.gridStart(new Date(year, month, +box[1]), +rows[0].children[0].innerText.trim(), weekday < 0 ? 1 : weekday);
    if (!start) return null;
    const rowBoxes = rows.map(r => r.getBoundingClientRect());
    const events = [];
    for (const el of document.querySelectorAll('.fc-event')) {
      const b = el.getBoundingClientRect();
      if (!b.width) continue;
      const cx = b.left + b.width / 2, cy = b.top + 4;
      const wk = rowBoxes.findIndex(rb => cy >= rb.top - 2 && cy < rb.bottom + 2);
      if (wk < 0) continue;
      const col = Array.from(rows[wk].children).findIndex(c => { const cb = c.getBoundingClientRect(); return cx >= cb.left && cx < cb.right; });
      if (col < 0) continue;
      const ev = S.shiftFromText(el.innerText, S.addDays(start, wk * 7 + col));
      if (ev) events.push(ev);
    }
    const hash = events.map(e => e.uid + '|' + S.signature(e)).sort().join('\n');
    return { monthKey: year + '-' + S.pad2(month + 1), rangeStart: S.ymd(start), rangeEnd: S.ymd(S.addDays(start, rows.length * 7)), events, hash };
  }

  function ensureUi() {
    if (ui) return ui;
    const host = document.createElement('div');
    host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;font:14px/1.3 system-ui,"Segoe UI",sans-serif;';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = '<style>' +
      '.pill{display:flex;align-items:center;background:#1d2420;color:#e8ece9;border-radius:999px;padding:8px 10px 8px 18px;box-shadow:0 6px 24px rgba(0,0,0,.35);max-width:min(460px,calc(100vw - 32px))}' +
      '.s{font-size:13px;color:#cfd8d3}.s:not(:empty){margin-right:12px}' +
      'button{font:inherit;font-weight:600;color:#0f1a15;background:#6fc3a8;border:0;border-radius:999px;padding:8px 14px;cursor:pointer;white-space:nowrap}' +
      'button:focus-visible{outline:2px solid #fff;outline-offset:2px}' +
      '</style><div class="pill"><span class="s" id="s" role="status"></span><button id="b" type="button"></button></div>';
    document.documentElement.appendChild(host);
    ui = { btn: root.getElementById('b'), status: root.getElementById('s') };
    ui.btn.addEventListener('click', () => runSync(true));
    return ui;
  }
  const setButton = label => { ensureUi().btn.textContent = label; };
  const setStatus = text => { ensureUi().status.textContent = text; ui.status.title = ''; };

  async function runSync(interactive) {
    if (busy) return;
    const roster = readRoster();
    if (!roster) return setStatus('Open the roster month view first.');
    busy = true; setButton('Syncing…'); setStatus('');
    try {
      const res = await api.runtime.sendMessage({ type: 'sync', interactive, roster: { monthKey: roster.monthKey, rangeStart: roster.rangeStart, rangeEnd: roster.rangeEnd, events: roster.events } });
      if (!res) throw new Error('no reply from the extension');
      if (res.needsAuth) {
        setButton('Connect Google Calendar');
        setStatus(interactive ? 'Google sign-in did not finish. Try again.' : 'Click Connect to sync these shifts to Google Calendar.');
      } else if (res.ok) {
        setButton('Sync again');
        setStatus(S.shifts(roster.events.length) + ' synced · ' + new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }));
      } else throw new Error(res.error || 'unknown error');
    } catch (e) {
      const detail = String(e && e.message || e);
      setButton('Try again');
      setStatus(/context invalidated/i.test(detail) ? 'Roster Sync was updated. Reload this page.' : "Couldn't sync. Click Try again.");
      ui.status.title = detail;
    } finally { busy = false; }
  }

  async function check() {
    if (busy) return schedule();
    const roster = readRoster();
    if (!roster) return;
    if (!ui) setButton('Sync to Google Calendar');
    // An empty grid is usually still loading, so only a click may clear a month.
    if (!roster.events.length) { lastHash = null; setButton('Sync to Google Calendar'); return setStatus('No shifts on screen.'); }
    if (roster.hash === lastHash) return;
    lastHash = roster.hash;
    const { autoSync = true } = await api.storage.sync.get('autoSync');
    if (autoSync) runSync(false);
    else setStatus(S.shifts(roster.events.length) + ' on screen. Automatic sync is off.');
  }
  const schedule = () => { clearTimeout(timer); timer = setTimeout(check, 800); };
  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  window.addEventListener('load', schedule);
  schedule();

  // The popup asks for the shifts to build an .ics file; only the frame that shows the roster answers.
  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'getRoster') return;
    const roster = readRoster();
    if (roster) sendResponse(roster);
  });
})();
