// Settings and pure helpers shared by the page script, background and popup (no DOM access). Tested by test/parse.test.js.
(function (root) {
  'use strict';
  const CONFIG = {
    clientId: '966386863384-e2vq2qmchhiqltk2801u8811qu4auimq.apps.googleusercontent.com', // Google OAuth client (README: Maintainer)
    calendarName: 'Work roster', // the Google calendar the shifts go into (created on first sync)
    timeZone: 'Australia/Sydney'
  };
  const NAMES = { D: 'Day shift', A: 'Early shift', P: 'Late shift', N: 'Night shift', OC: 'On call', ADO: 'ADO', 'CONF EXT': 'Conference (external)' };
  // Google Calendar's 11 event colours (colorId: name, swatch), the only ones an event can have.
  const GOOGLE_COLORS = { 1: ['Lavender', '#7986cb'], 2: ['Sage', '#33b679'], 3: ['Grape', '#8e24aa'], 4: ['Flamingo', '#e67c73'], 5: ['Banana', '#f6bf26'], 6: ['Tangerine', '#f4511e'], 7: ['Peacock', '#039be5'], 8: ['Graphite', '#616161'], 9: ['Blueberry', '#3f51b5'], 10: ['Basil', '#0b8043'], 11: ['Tomato', '#d50000'] };
  // Kinds of shift with their standard colours, as on the website; the popup lets people pick others. Other timed
  // codes keep the calendar's own colour.
  const KINDS = { D: ['Day shift', '2'], A: ['Early shift', '5'], P: ['Late shift', '6'], N: ['Night shift', '9'], OC: ['On call', '3'], allDay: ['Leave and all-day codes', '8'], changed: ['Changed shift', '11'] };
  // A chosen colour ('' for the calendar's own) wins over the standard one.
  const colorFor = (kind, chosen = {}) => (kind in chosen ? chosen[kind] : (KINDS[kind] || [])[1]) || undefined;
  const pad2 = n => String(n).padStart(2, '0');
  const ymd = d => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
  const addDays = (d, n) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; };
  const addDaysStr = (s, n) => ymd(addDays(new Date(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)), n));
  const local = (d, h, m) => ymd(d) + 'T' + pad2(h) + ':' + pad2(m) + ':00';
  const shifts = n => n + (n === 1 ? ' shift' : ' shifts');

  // First date shown in the grid: the latest date on or before the selected one that has the first cell's day
  // number and falls on the grid's first weekday. Fits Employee Online's rolling 4-week view (starts the Monday of
  // the selected date) and a calendar-month view (starts the Monday before the 1st). null if nothing matches.
  function gridStart(selected, firstCell, firstWeekday = 1) {
    for (let d = selected, i = 0; i < 42; i++, d = addDays(d, -1)) if (d.getDate() === firstCell && d.getDay() === firstWeekday) return d;
    return null;
  }

  // One roster cell on a given day: "D 08:30 - 17:00 @ Biochem", "N 23:00 - 07:00", "ADO 8hr", "CONF EXT 00:00".
  // Returns null for a day off ("DO"). Times are local wall-clock times (no offset).
  function shiftFromText(txt, day) {
    txt = String(txt).replace(/\s+/g, ' ').trim();
    const m = txt.match(/^(.+?) (\d{2}):(\d{2}) - (\d{2}):(\d{2})(?: @ (.+))?$/);
    if (m) {
      const code = m[1], loc = m[6] || '';
      const sh = +m[2], sm = +m[3], eh = +m[4], em = +m[5];
      const crossesMidnight = eh * 60 + em <= sh * 60 + sm;
      return {
        uid: 'eol-' + ymd(day) + '-' + code.replace(/\W+/g, '_') + '-' + m[2] + m[3],
        summary: (NAMES[code] || code) + (loc ? ' \u00b7 ' + loc : ''),
        location: loc, allDay: false, kind: KINDS[code] ? code : undefined,
        start: local(day, sh, sm), end: local(crossesMidnight ? addDays(day, 1) : day, eh, em),
        source: txt
      };
    }
    const code = txt.replace(/ 00:00$/, '').replace(/ [\d.]+hr$/, '').trim();
    if (!code || code === 'DO') return null;
    return { uid: 'eol-' + ymd(day) + '-' + code.replace(/\W+/g, '_'), summary: NAMES[code] || code, location: '', allDay: true, kind: 'allDay', start: ymd(day), end: ymd(addDays(day, 1)), source: txt };
  }

  // Google Calendar event ids may only contain 0-9 and a-v, so the uid is hex encoded.
  const eventId = uid => Array.from(uid, c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('');
  const signature = ev => [ev.summary, ev.start, ev.end, ev.location || ''].join('|');
  // A signature back in words, for a changed shift's notes: "Day shift · Biochem, 8:30 am – 5:00 pm" or "ADO (all day)".
  const clock = s => { const h = +s.slice(11, 13); return (h % 12 || 12) + ':' + s.slice(14, 16) + (h < 12 ? ' am' : ' pm'); };
  const describe = sig => { const [summary, start, end] = sig.split('|'); return summary + (start.length > 10 ? ', ' + clock(start) + ' – ' + clock(end) : ' (all day)'); };

  // Wall-clock time in CONFIG.timeZone -> UTC "YYYYMMDDTHHMMSSZ", which every calendar app reads the same way.
  function utc(localTime, fmt) {
    const [y, mo, d, h, mi] = localTime.match(/\d+/g).map(Number);
    const wall = Date.UTC(y, mo - 1, d, h, mi);
    const offset = t => { const p = Object.fromEntries(fmt.formatToParts(t).map(x => [x.type, +x.value])); return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute) - t; };
    return new Date(wall - offset(wall - offset(wall))).toISOString().replace(/[-:]|\.\d+/g, '');
  }

  const icsEsc = s => String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,');
  function icsFromEvents(events) {
    const fmt = new Intl.DateTimeFormat('en-AU', { timeZone: CONFIG.timeZone, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' });
    const stamp = new Date().toISOString().replace(/[-:]|\.\d+/g, '');
    const out = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Roster Sync//EN', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:' + icsEsc(CONFIG.calendarName)];
    for (const ev of events) {
      out.push('BEGIN:VEVENT', 'UID:' + ev.uid + '@roster-sync', 'DTSTAMP:' + stamp);
      if (ev.allDay) out.push('DTSTART;VALUE=DATE:' + ev.start.replace(/-/g, ''), 'DTEND;VALUE=DATE:' + ev.end.replace(/-/g, ''));
      else out.push('DTSTART:' + utc(ev.start, fmt), 'DTEND:' + utc(ev.end, fmt));
      out.push('SUMMARY:' + icsEsc(ev.summary));
      if (ev.location) out.push('LOCATION:' + icsEsc(ev.location));
      out.push('END:VEVENT');
    }
    out.push('END:VCALENDAR');
    return out.join('\r\n') + '\r\n';
  }

  root.RosterShared = { CONFIG, pad2, ymd, addDays, addDaysStr, gridStart, shifts, shiftFromText, eventId, signature, describe, icsFromEvents, GOOGLE_COLORS, KINDS, colorFor };
})(globalThis);
if (typeof module !== 'undefined') module.exports = globalThis.RosterShared;
